import tkinter as tk

from tkinter import messagebox
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import networkx as nx

# Inicialización con 12 productos
productos = {
    "1": {"nombre": "Coca-Cola", "precio": 3000, "imagen": "imagen/coca.png"},
    "2": {"nombre": "Agua", "precio": 2000, "imagen": "imagen/agua.png"},
    "3": {"nombre": "Galletas Oreo", "precio": 1500, "imagen": "imagen/oreo.png"},
    "4": {"nombre": "Galletas Festival", "precio": 1000, "imagen": "imagen/festival.png"},
    "5": {"nombre": "Pepsi", "precio": 2500, "imagen": "imagen/pepsi.png"},
    "6": {"nombre": "Papas de Pollo", "precio": 3500, "imagen": "imagen/papas.png"},
    "7": {"nombre": "Gancito", "precio": 4000, "imagen": "imagen/gancito.png"},
    "8": {"nombre": "Jugo Hit", "precio": 4500, "imagen": "imagen/jugo-hit.png"},
    "9": {"nombre": "Panecillo", "precio": 1500, "imagen": "imagen/pan.png"},
    "10": {"nombre": "Bonbonbum", "precio": 1000, "imagen": "imagen/colombina.png"},
    "11": {"nombre": "Jugo del Valle", "precio": 5500, "imagen": "imagen/valle.png"},
    "12": {"nombre": "Speedmax", "precio": 5000, "imagen": "imagen/speed.png"}
}

dinero_ingresado = 0

# Tabla de transiciones del autómata
transiciones = {
    "q1": {"0": "q2", "1": "q3"},
    "q2": {"0": "q4", "1": "q1"},
    "q3": {"0": "q5", "1": "q1"},
    "q4": {"0": "q4", "1": "q1"},
    "q5": {"0": "q5", "1": "q1"}
}

estado_inicial = "q1"

# Función para procesar la compra
def procesar_compra(event=None):
    try:
        binario = dinero_entry.get()
        dinero = binario.count('1') * 1000 + binario.count('0') * 500

        productos_ordenados = sorted(productos.items(), key=lambda item: item[1]['precio'], reverse=True)

        for clave, producto in productos_ordenados:
            if producto["precio"] <= dinero:
                mensaje = f"Ha seleccionado {producto['nombre']}. Precio: ${producto['precio']:.2f}"
                messagebox.showinfo("Producto Seleccionado", mensaje)

                if dinero >= producto["precio"]:
                    messagebox.showinfo("Producto Entregado", f"Su cambio es: ${dinero - producto['precio']:.2f}")
                    global dinero_ingresado
                    dinero_ingresado += producto["precio"]
                    actualizar_imagen(producto["imagen"])
                    actualizar_grafo(binario)
                    mostrar_tabla_transiciones(binario)
                else:
                    messagebox.showwarning("Error", "No ha ingresado suficiente dinero.")
                break
        else:
            messagebox.showerror("Producto no disponible", "No hay productos con ese precio.")
    except ValueError:
        messagebox.showerror("Entrada inválida", "Por favor, ingresa una secuencia válida de ceros y unos.")

# Función para actualizar la imagen del producto
def actualizar_imagen(ruta_imagen):
    imagen = Image.open(ruta_imagen)
    imagen = imagen.resize((150, 150))  # Ajusta el tamaño de la imagen
    img = ImageTk.PhotoImage(imagen)
    imagen_label.config(image=img)
    imagen_label.image = img

# Función para mostrar la lista de precios
def mostrar_precios():
    precios_texto = "Lista de Precios:\n"
    for clave, producto in productos.items():
        precios_texto += f"{clave}. {producto['nombre']}: ${producto['precio']}\n"
    precios_label.config(text=precios_texto)

# Función para mostrar las imágenes de los productos en 4 filas y 3 columnas
def mostrar_imagenes():
    for i, (clave, producto) in enumerate(productos.items()):
        imagen = Image.open(producto["imagen"])
        imagen = imagen.resize((80, 80))
        img = ImageTk.PhotoImage(imagen)

        row = i // 3 + 2  # Ajustar la fila de inicio
        column = i % 3
        imagen_label = tk.Label(root, image=img)
        imagen_label.image = img
        imagen_label.grid(row=row, column=column, padx=10, pady=10)

        # Colocar nombre y precio debajo de la imagen
        nombre_precio = f"{producto['nombre']} - ${producto['precio']}"
        precio_label = tk.Label(root, text=nombre_precio, font=("Arial", 10))
        precio_label.grid(row=row + 1, column=column)  # Debajo de la imagen

# Función para actualizar el grafo de autómata basado en la secuencia ingresada
def actualizar_grafo(secuencia):
    G = nx.DiGraph()
    estado_actual = estado_inicial
    nodos_recorridos = [estado_actual]

    for simbolo in secuencia:
        estado_siguiente = transiciones.get(estado_actual, {}).get(simbolo)
        if estado_siguiente:
            G.add_edge(estado_actual, estado_siguiente, label=simbolo)
            estado_actual = estado_siguiente
            nodos_recorridos.append(estado_actual)
        else:
            break

    pos = nx.spring_layout(G)
    plt.clf()
    nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=2000, font_size=10, font_color='black', edge_color='black')
    nx.draw_networkx_edge_labels(G, pos, edge_labels={(n1, n2): simbolo for n1, n2, simbolo in G.edges(data='label')})

    canvas_grafo = FigureCanvasTkAgg(plt.gcf(), master=root)
    canvas_grafo.get_tk_widget().grid(row=1, column=3, rowspan=5, padx=10, pady=10)

# Función para mostrar la tabla de transiciones
def mostrar_tabla_transiciones(secuencia):
    estado_actual = estado_inicial
    transiciones_texto = "Tabla de Transiciones:\n"
    transiciones_texto += "Estado Actual | Símbolo | Estado Siguiente\n"
    transiciones_texto += "-" * 40 + "\n"

    # Recorrer la secuencia y mostrar cada transición
    for simbolo in secuencia:
        estado_siguiente = transiciones.get(estado_actual, {}).get(simbolo)
        if estado_siguiente:
            transiciones_texto += f"     {estado_actual}       |    {simbolo}    |        {estado_siguiente}\n"
            estado_actual = estado_siguiente
        else:
            transiciones_texto += f"     {estado_actual}       |    {simbolo}    |        ---\n"  # No hay transición
            break

    transiciones_label.config(text=transiciones_texto)

# Crear la ventana principal
root = tk.Tk()
root.title("Máquina Expendedora Automática")
root.geometry("900x700")

# Etiqueta para el título
titulo_label = tk.Label(root, text="Máquina Expendedora Automática", font=("Arial", 16))
titulo_label.grid(row=0, column=0, columnspan=3, pady=10)

# Caja de texto para ingresar la secuencia de 0s y 1s
dinero_entry = tk.Entry(root)
dinero_entry.grid(row=1, column=0, padx=10, pady=10)
dinero_entry.bind("<Return>", procesar_compra)

# Marco amarillo para la imagen del producto seleccionado
imagen_frame = tk.Frame(root, bg="yellow", padx=10, pady=10)
imagen_frame.grid(row=1, column=3, padx=50)

# Mostrar la imagen del producto seleccionado
imagen_label = tk.Label(imagen_frame)
imagen_label.grid()

# Mostrar la lista de precios
precios_label = tk.Label(root, text="", font=("Arial", 12), justify="left")
precios_label.grid(row=0, column=1, padx=10, pady=5, sticky="w")  # Subir la lista de precios
mostrar_precios()

# Mostrar las imágenes de los productos
mostrar_imagenes()

# Crear la etiqueta para la tabla de transiciones
transiciones_label = tk.Label(root, text="", font=("Arial", 10), justify="left")
transiciones_label.grid(row=6, column=0, columnspan=3, padx=10, pady=10)

root.mainloop()

