import turtle

class TortugaControl:
    def __init__(self):
        # Inicializa la pantalla y la tortuga
        self.ventana = turtle.Screen()
        self.ventana.title("Controla la Tortuga con Comandos Binarios")  # Título de la ventana
        
        # Crear la tortuga
        self.mi_tortuga = turtle.Turtle()
        
        # Configurar los controles
        self.configurar_controles()
    
    def configurar_controles(self):
        """Configura las teclas para ingresar comandos binarios."""
        self.ventana.listen()  # La ventana está lista para "escuchar" las teclas
        self.ventana.onkey(lambda: self.ejecutar_comando('00'), "0")  # Comando para '00' usando la tecla '0'
        self.ventana.onkey(lambda: self.ejecutar_comando('01'), "1")  # Comando para '01' usando la tecla '1'
        self.ventana.onkey(lambda: self.ejecutar_comando('10'), "2")  # Comando para '10' usando la tecla '2'
        self.ventana.onkey(lambda: self.ejecutar_comando('11'), "3")  # Comando para '11' usando la tecla '3'
    
    def mover_adelante(self):
        """Mueve la tortuga hacia adelante."""
        self.mi_tortuga.forward(20)  # Mueve la tortuga 20 pasos hacia adelante
    
    def mover_atras(self):
        """Mueve la tortuga hacia atrás."""
        self.mi_tortuga.backward(20)  # Mueve la tortuga 20 pasos hacia atrás
    
    def girar_izquierda(self):
        """Gira la tortuga a la izquierda."""
        self.mi_tortuga.left(30)  # Gira la tortuga 30 grados a la izquierda
    
    def girar_derecha(self):
        """Gira la tortuga a la derecha."""
        self.mi_tortuga.right(30)  # Gira la tortuga 30 grados a la derecha
    
    def ejecutar_comando(self, comando_binario):
        """Ejecuta un comando basado en la entrada binaria."""
        if comando_binario == '00':
            self.mover_adelante()
        elif comando_binario == '01':
            self.mover_atras()
        elif comando_binario == '10':
            self.girar_izquierda()
        elif comando_binario == '11':
            self.girar_derecha()
        else:
            print("Comando no reconocido. Use '00', '01', '10', o '11'.")
    
    def ejecutar(self):
        """Ejecuta el bucle principal del programa."""
        self.ventana.mainloop()

# Crear una instancia de TortugaControl
mi_controlador = TortugaControl()

# Ejecutar el programa
mi_controlador.ejecutar()
