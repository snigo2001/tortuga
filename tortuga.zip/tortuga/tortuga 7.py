import turtle
import tkinter as tk  # Importar Tkinter para crear la interfaz gráfica

class TortugaControl:
    def __init__(self):
        """Inicializa la ventana de Tkinter, los lienzos de Turtle, y los comandos."""
        # Crear la ventana principal de Tkinter
        self.root = tk.Tk()
        self.root.title("Control de Tortuga con Comandos Binarios")

        # Crear un marco para los comandos de entrada
        self.frame_comandos = tk.Frame(self.root)
        self.frame_comandos.pack(side=tk.TOP, padx=10, pady=10)

        # Etiqueta y cuadro de texto para ingresar comandos
        self.label = tk.Label(self.frame_comandos, text="Ingresa comandos binarios:")
        self.label.pack(side=tk.LEFT)
        
        self.entrada_comandos = tk.Entry(self.frame_comandos, width=30)
        self.entrada_comandos.pack(side=tk.LEFT)
        
        # Botón para ejecutar comandos
        self.boton_ejecutar = tk.Button(self.frame_comandos, text="Ejecutar", command=self.procesar_comandos)
        self.boton_ejecutar.pack(side=tk.LEFT)

        # Crear un lienzo de Turtle para la tortuga
        self.canvas_tortuga = turtle.ScrolledCanvas(self.root, width=600, height=400)
        self.canvas_tortuga.pack(side=tk.LEFT)
        self.ventana_tortuga = turtle.TurtleScreen(self.canvas_tortuga)
        self.ventana_tortuga.bgcolor("black")  # Fondo negro

        # Crear la tortuga
        self.mi_tortuga = turtle.RawTurtle(self.ventana_tortuga)
        self.mi_tortuga.color("green")
        self.mi_tortuga.shape("turtle")
        
        # Crear cuadrícula de fondo en la ventana de tortuga
        self.dibujar_cuadricula()

        # Crear un lienzo de Turtle para el diagrama del autómata
        self.canvas_diagrama = turtle.ScrolledCanvas(self.root, width=400, height=400)
        self.canvas_diagrama.pack(side=tk.RIGHT)
        self.ventana_diagrama = turtle.TurtleScreen(self.canvas_diagrama)
        self.ventana_diagrama.bgcolor("white")  # Fondo blanco

        self.diagrama_tortuga = turtle.RawTurtle(self.ventana_diagrama)
        self.diagrama_tortuga.speed(0)
        self.diagrama_tortuga.hideturtle()

        # Dibujar el diagrama del autómata
        self.dibujar_diagrama_autómata(self.diagrama_tortuga)

        # Diccionario de comandos binarios
        self.comandos = {
            '00': self.girar_izquierda,
            '01': self.mover_adelante,
            '10': self.mover_atras,
            '11': self.girar_derecha
        }

    def dibujar_cuadricula(self):
        """Dibuja una cuadrícula blanca en el fondo de la ventana de la tortuga."""
        grid_drawer = turtle.RawTurtle(self.ventana_tortuga)
        grid_drawer.speed(0)
        grid_drawer.color("white")
        grid_drawer.penup()

        # Configurar la cuadrícula
        step = 20  # Espacio entre líneas de la cuadrícula
        window_size = 400  # Tamaño de la ventana

        # Dibujar líneas verticales
        for x in range(-window_size, window_size + step, step):
            grid_drawer.goto(x, -window_size)
            grid_drawer.pendown()
            grid_drawer.goto(x, window_size)
            grid_drawer.penup()

        # Dibujar líneas horizontales
        for y in range(-window_size, window_size + step, step):
            grid_drawer.goto(-window_size, y)
            grid_drawer.pendown()
            grid_drawer.goto(window_size, y)
            grid_drawer.penup()

        grid_drawer.hideturtle()

    def procesar_comandos(self):
        """Procesa los comandos binarios ingresados por el usuario."""
        cadena_binaria = self.entrada_comandos.get()
        if cadena_binaria:
            # Recorrer la cadena en bloques de 2 caracteres
            for i in range(0, len(cadena_binaria), 2):
                comando_binario = cadena_binaria[i:i+2]
                if comando_binario in self.comandos:
                    accion = self.comandos[comando_binario]
                    accion()
                else:
                    print(f"Comando '{comando_binario}' no reconocido. Use '00', '01', '10', o '11'.")
        else:
            print("No se ingresó ninguna cadena válida.")

    def mover_adelante(self):
        """Mueve la tortuga hacia adelante."""
        self.mi_tortuga.forward(20)
    
    def mover_atras(self):
        """Mueve la tortuga hacia atrás."""
        self.mi_tortuga.backward(20)
    
    def girar_izquierda(self):
        """Gira la tortuga a la izquierda."""
        self.mi_tortuga.left(30)
    
    def girar_derecha(self):
        """Gira la tortuga a la derecha."""
        self.mi_tortuga.right(30)

    def dibujar_diagrama_autómata(self, diagrama_tortuga):
        """Dibuja un diagrama de autómata simple."""
        diagrama_tortuga.penup()

        # Dibujar estados
        estados = {
            'q0': (-150, 0),
            'q1': (-50, 100),
            'q2': (50, 0),
            'q3': (150, -100),
            'q4': (250, 0)
        }
        for estado, (x, y) in estados.items():
            diagrama_tortuga.goto(x, y)
            diagrama_tortuga.dot(40, "black")
            diagrama_tortuga.write(estado, align="center", font=("Arial", 12, "bold"))

        # Dibujar transiciones entre estados
        transiciones = {
            ('q0', 'q1'): '01',  # q0 -> q1 con comando '01' (adelante)
            ('q1', 'q2'): '10',  # q1 -> q2 con comando '10' (atrás)
            ('q2', 'q3'): '00',  # q2 -> q3 con comando '00' (izquierda)
            ('q3', 'q4'): '11'   # q3 -> q4 con comando '11' (derecha)
        }

        for (origen, destino), comando in transiciones.items():
            self.dibujar_transicion(diagrama_tortuga, origen, destino, comando)

    def dibujar_transicion(self, diagrama_tortuga, origen, destino, comando):
        """Dibuja una flecha para representar una transición de un estado a otro."""
        # Coordenadas de los estados
        estados = {
            'q0': (-150, 0),
            'q1': (-50, 100),
            'q2': (50, 0),
            'q3': (150, -100),
            'q4': (250, 0)
        }
        x_origen, y_origen = estados[origen]
        x_destino, y_destino = estados[destino]

        # Dibujar flecha
        diagrama_tortuga.penup()
        diagrama_tortuga.goto(x_origen, y_origen)
        diagrama_tortuga.pendown()
        diagrama_tortuga.goto(x_destino, y_destino)
        diagrama_tortuga.penup()

        # Colocar etiqueta del comando
        x_medio = (x_origen + x_destino) / 2
        y_medio = (y_origen + y_destino) / 2
        diagrama_tortuga.goto(x_medio, y_medio)
        diagrama_tortuga.write(comando, align="center", font=("Arial", 12, "normal"))

    def ejecutar(self):
        """Ejecuta el bucle principal de la ventana de Tkinter."""
        self.root.mainloop()

# Crear una instancia de TortugaControl
mi_controlador = TortugaControl()

# Ejecutar el programa
mi_controlador.ejecutar()
