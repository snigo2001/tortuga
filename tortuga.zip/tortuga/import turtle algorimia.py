import turtle

# Definir los estados del autómata
class TurtleAutomaton:
    def __init__(self):
        # Inicializar la pantalla
        self.window = turtle.Screen()
        self.window.title("Autómata de Tortuga - Control con Teclas WASD")
        
        # Inicializar la tortuga
        self.t = turtle.Turtle()
        
        # Estado inicial (posición inicial y orientación de la tortuga)
        self.state = {"x": 0, "y": 0, "direction": 0}
    
        # Configurar los eventos de teclado
        self.window.listen()  # Permitir que la ventana escuche eventos del teclado
        self.window.onkey(self.move_forward, "w")     # Tecla 'w' para avanzar
        self.window.onkey(self.move_backward, "s")    # Tecla 's' para retroceder
        self.window.onkey(self.turn_left, "a")        # Tecla 'a' para girar a la izquierda
        self.window.onkey(self.turn_right, "d")       # Tecla 'd' para girar a la derecha
    
    def move_forward(self):
        """Mover la tortuga hacia adelante."""
        self.t.forward(20)  # Mueve la tortuga 20 unidades hacia adelante
        self.update_state()
    
    def move_backward(self):
        """Mover la tortuga hacia atrás."""
        self.t.backward(20)  # Mueve la tortuga 20 unidades hacia atrás
        self.update_state()
    
    def turn_left(self):
        """Girar la tortuga a la izquierda."""
        self.t.left(30)  # Gira la tortuga 30 grados a la izquierda
        self.update_state()
    
    def turn_right(self):
        """Girar la tortuga a la derecha."""
        self.t.right(30)  # Gira la tortuga 30 grados a la derecha
        self.update_state()
    
    def update_state(self):
        """Actualizar el estado actual del autómata."""
        self.state["x"], self.state["y"] = self.t.position()
        self.state["direction"] = self.t.heading()
        print(f"Estado actual: {self.get_state()}")
    
    def get_state(self):
        """Obtener el estado actual del autómata."""
        return self.state
    
    def run(self):
        """Ejecutar el bucle principal del programa."""
        self.window.mainloop()

# Crear una instancia del autómata
automaton = TurtleAutomaton()

# Ejecutar el ciclo principal del autómata
automaton.run()
