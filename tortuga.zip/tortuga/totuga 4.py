import turtle

class TortugaControl:
    def __init__(self):
        """Inicializa la pantalla, la tortuga y los comandos."""
        self.ventana = turtle.Screen()
        self.ventana.title("Controla la Tortuga con Comandos Binarios")  # Título de la ventana
        
        # Establecer el color de fondo de la ventana
        self.ventana.bgcolor("black")  # Fondo negro
        
        # Crear la tortuga, establecer su color y su forma
        self.mi_tortuga = turtle.Turtle()
        self.mi_tortuga.color("green")  # Tortuga verde
        self.mi_tortuga.shape("turtle")  # Forma de tortuga
        
        # Crear cuadrícula de fondo
        self.dibujar_cuadricula()
        
        # Ocultar la tortuga mientras muestra las instrucciones
        self.mi_tortuga.hideturtle()

        # Mostrar instrucciones en pantalla
        self.mostrar_instrucciones()

        # Mostrar la tortuga nuevamente
        self.mi_tortuga.showturtle()

        # Diccionario de comandos binarios
        self.comandos = {
            '00': self.girar_izquierda,
            '01': self.mover_adelante,
            '10': self.mover_atras,
            '11': self.girar_derecha
        }

        # Variable para guardar la cadena de comandos
        self.cadena_binaria = ""

    def mostrar_instrucciones(self):
        """Muestra las instrucciones de movimiento usando comandos binarios."""
        instrucciones = (
            "Instrucciones de movimiento:\n"
            "00: Izquierda\n"
            "01: Adelante\n"
            "10: Atrás\n"
            "11: Derecha\n"
            "Ingresa una cadena de texto binaria (ejemplo: '010011') para mover la tortuga."
        )
        texto_instrucciones = turtle.Turtle()
        texto_instrucciones.color("white")
        texto_instrucciones.penup()
        texto_instrucciones.hideturtle()
        texto_instrucciones.goto(0, 200)  # Posición del texto
        texto_instrucciones.write(instrucciones, align="center", font=("Arial", 16, "bold"))

    def dibujar_cuadricula(self):
        """Dibuja una cuadrícula blanca en el fondo de la ventana."""
        grid_drawer = turtle.Turtle()
        grid_drawer.speed(0)  # Velocidad máxima para dibujar rápidamente
        grid_drawer.color("white")
        grid_drawer.penup()

        # Configurar la cuadrícula
        step = 20  # Espacio entre líneas de la cuadrícula
        window_size = 400  # Tamaño de la ventana

        # Dibujar líneas verticales
        for x in range(-window_size, window_size + step, step):
            grid_drawer.goto(x, -window_size)
            grid_drawer.pendown()
            grid_drawer.goto(x, window_size)
            grid_drawer.penup()

        # Dibujar líneas horizontales
        for y in range(-window_size, window_size + step, step):
            grid_drawer.goto(-window_size, y)
            grid_drawer.pendown()
            grid_drawer.goto(window_size, y)
            grid_drawer.penup()

        grid_drawer.hideturtle()

    def recibir_cadena(self):
        """Recibe una cadena de texto binaria del usuario."""
        self.cadena_binaria = self.ventana.textinput("Entrada de comandos", "Ingresa una cadena binaria para mover la tortuga:")

    def procesar_comandos(self):
        """Procesa los comandos en la cadena de texto binaria."""
        if self.cadena_binaria:
            # Recorrer la cadena en bloques de 2 caracteres
            for i in range(0, len(self.cadena_binaria), 2):
                comando_binario = self.cadena_binaria[i:i+2]
                if comando_binario in self.comandos:
                    accion = self.comandos[comando_binario]
                    accion()
                else:
                    print(f"Comando '{comando_binario}' no reconocido. Use '00', '01', '10', o '11'.")
        else:
            print("No se ingresó ninguna cadena válida.")

    def mover_adelante(self):
        """Mueve la tortuga hacia adelante."""
        self.mi_tortuga.forward(20)  # Mueve la tortuga 20 pasos hacia adelante
    
    def mover_atras(self):
        """Mueve la tortuga hacia atrás."""
        self.mi_tortuga.backward(20)  # Mueve la tortuga 20 pasos hacia atrás
    
    def girar_izquierda(self):
        """Gira la tortuga a la izquierda."""
        self.mi_tortuga.left(30)  # Gira la tortuga 30 grados a la izquierda
    
    def girar_derecha(self):
        """Gira la tortuga a la derecha."""
        self.mi_tortuga.right(30)  # Gira la tortuga 30 grados a la derecha
    
    def ejecutar(self):
        """Ejecuta el bucle principal del programa y espera la entrada del usuario."""
        while True:
            self.recibir_cadena()
            if self.cadena_binaria is None:  # Si el usuario cierra el cuadro de entrada, salir del bucle
                break
            self.procesar_comandos()
        self.ventana.bye()  # Cierra la ventana de turtle

# Crear una instancia de TortugaControl
mi_controlador = TortugaControl()

# Ejecutar el programa
mi_controlador.ejecutar()

