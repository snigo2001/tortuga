import turtle

class TortugaControl:
    def __init__(self):
        """Inicializa la pantalla, la tortuga y los comandos."""
        # Configuración de la ventana principal para el movimiento de la tortuga
        self.ventana = turtle.Screen()
        self.ventana.title("Controla la Tortuga con Comandos Binarios")  # Título de la ventana
        self.ventana.bgcolor("black")  # Fondo negro
        
        # Crear la tortuga, establecer su color y su forma
        self.mi_tortuga = turtle.Turtle()
        self.mi_tortuga.color("green")  # Tortuga verde
        self.mi_tortuga.shape("turtle")  # Forma de tortuga
        
        # Crear cuadrícula de fondo
        self.dibujar_cuadricula()
        
        # Ocultar la tortuga mientras muestra las instrucciones
        self.mi_tortuga.hideturtle()

        # Mostrar instrucciones en pantalla
        self.mostrar_instrucciones()

        # Mostrar la tortuga nuevamente
        self.mi_tortuga.showturtle()

        # Diccionario de comandos binarios
        self.comandos = {
            '00': self.girar_izquierda,
            '01': self.mover_adelante,
            '10': self.mover_atras,
            '11': self.girar_derecha
        }

        # Variable para guardar la cadena de comandos
        self.cadena_binaria = ""

        # Configurar ventana secundaria para el diagrama de autómata
        self.ventana_diagrama = turtle.TurtleScreen(turtle.getcanvas())
        self.ventana_diagrama.title("Diagrama de Autómata")

        # Crear tortuga para dibujar el diagrama de autómata
        self.diagrama_tortuga = turtle.RawTurtle(self.ventana_diagrama)
        self.diagrama_tortuga.speed(0)
        self.diagrama_tortuga.hideturtle()

        # Dibujar el diagrama inicial de autómata
        self.dibujar_diagrama_autómata()

    def mostrar_instrucciones(self):
        """Muestra las instrucciones de movimiento usando comandos binarios."""
        instrucciones = (
            "Instrucciones de movimiento:\n"
            "00: Izquierda\n"
            "01: Adelante\n"
            "10: Atrás\n"
            "11: Derecha\n"
            "Ingresa una cadena de texto binaria (ejemplo: '010011') para mover la tortuga."
        )
        texto_instrucciones = turtle.Turtle()
        texto_instrucciones.color("white")
        texto_instrucciones.penup()
        texto_instrucciones.hideturtle()
        texto_instrucciones.goto(0, 200)  # Posición del texto
        texto_instrucciones.write(instrucciones, align="center", font=("Arial", 16, "bold"))

    def dibujar_cuadricula(self):
        """Dibuja una cuadrícula blanca en el fondo de la ventana."""
        grid_drawer = turtle.Turtle()
        grid_drawer.speed(0)  # Velocidad máxima para dibujar rápidamente
        grid_drawer.color("white")
        grid_drawer.penup()

        # Configurar la cuadrícula
        step = 20  # Espacio entre líneas de la cuadrícula
        window_size = 400  # Tamaño de la ventana

        # Dibujar líneas verticales
        for x in range(-window_size, window_size + step, step):
            grid_drawer.goto(x, -window_size)
            grid_drawer.pendown()
            grid_drawer.goto(x, window_size)
            grid_drawer.penup()

        # Dibujar líneas horizontales
        for y in range(-window_size, window_size + step, step):
            grid_drawer.goto(-window_size, y)
            grid_drawer.pendown()
            grid_drawer.goto(window_size, y)
            grid_drawer.penup()

        grid_drawer.hideturtle()

    def recibir_cadena(self):
        """Recibe una cadena de texto binaria del usuario."""
        self.cadena_binaria = self.ventana.textinput("Entrada de comandos", "Ingresa una cadena binaria para mover la tortuga:")

    def procesar_comandos(self):
        """Procesa los comandos en la cadena de texto binaria."""
        if self.cadena_binaria:
            # Recorrer la cadena en bloques de 2 caracteres
            for i in range(0, len(self.cadena_binaria), 2):
                comando_binario = self.cadena_binaria[i:i+2]
                if comando_binario in self.comandos:
                    accion = self.comandos[comando_binario]
                    accion()
                    self.actualizar_diagrama(comando_binario)
                else:
                    print(f"Comando '{comando_binario}' no reconocido. Use '00', '01', '10', o '11'.")
        else:
            print("No se ingresó ninguna cadena válida.")

    def mover_adelante(self):
        """Mueve la tortuga hacia adelante."""
        self.mi_tortuga.forward(20)  # Mueve la tortuga 20 pasos hacia adelante
    
    def mover_atras(self):
        """Mueve la tortuga hacia atrás."""
        self.mi_tortuga.backward(20)  # Mueve la tortuga 20 pasos hacia atrás
    
    def girar_izquierda(self):
        """Gira la tortuga a la izquierda."""
        self.mi_tortuga.left(30)  # Gira la tortuga 30 grados a la izquierda
    
    def girar_derecha(self):
        """Gira la tortuga a la derecha."""
        self.mi_tortuga.right(30)  # Gira la tortuga 30 grados a la derecha

    def dibujar_diagrama_autómata(self):
        """Dibuja un diagrama de autómata simple."""
        self.diagrama_tortuga.clear()
        self.diagrama_tortuga.penup()

        # Dibujar estados
        estados = {
            'q0': (-200, 0),
            'q1': (-100, 100),
            'q2': (0, 0),
            'q3': (100, -100),
            'q4': (200, 0)
        }
        for estado, (x, y) in estados.items():
            self.diagrama_tortuga.goto(x, y)
            self.diagrama_tortuga.dot(40, "white")
            self.diagrama_tortuga.write(estado, align="center", font=("Arial", 12, "bold"))

        # Dibujar transiciones entre estados
        transiciones = {
            ('q0', 'q1'): '01',  # q0 -> q1 con comando '01' (adelante)
            ('q1', 'q2'): '10',  # q1 -> q2 con comando '10' (atrás)
            ('q2', 'q3'): '00',  # q2 -> q3 con comando '00' (izquierda)
            ('q3', 'q4'): '11'   # q3 -> q4 con comando '11' (derecha)
        }

        for (origen, destino), comando in transiciones.items():
            self.dibujar_transicion(origen, destino, comando)

    def dibujar_transicion(self, origen, destino, comando):
        """Dibuja una flecha para representar una transición de un estado a otro."""
        # Coordenadas de los estados
        estados = {
            'q0': (-200, 0),
            'q1': (-100, 100),
            'q2': (0, 0),
            'q3': (100, -100),
            'q4': (200, 0)
        }
        x_origen, y_origen = estados[origen]
        x_destino, y_destino = estados[destino]

        # Dibujar flecha
        self.diagrama_tortuga.penup()
        self.diagrama_tortuga.goto(x_origen, y_origen)
        self.diagrama_tortuga.pendown()
        self.diagrama_tortuga.goto(x_destino, y_destino)
        self.diagrama_tortuga.penup()

        # Colocar etiqueta del comando
        x_medio = (x_origen + x_destino) / 2
        y_medio = (y_origen + y_destino) / 2
        self.diagrama_tortuga.goto(x_medio, y_medio)
        self.diagrama_tortuga.write(comando, align="center", font=("Arial", 12, "normal"))

    def actualizar_diagrama(self, comando_binario):
        """Actualiza el diagrama del autómata para resaltar el estado actual."""
        # Aquí se puede agregar lógica para resaltar el estado actual o la transición según el comando recibido.
        print(f"Ejecutando comando {comando_binario}, actualizando diagrama...")

    def ejecutar(self):
        """Ejecuta el bucle principal del programa y espera la entrada del usuario."""
        while True:
            self.recibir_cadena()
            if self.cadena_binaria is None:  # Si el usuario cierra el cuadro de entrada, salir del bucle
                break
            self.procesar_comandos()
        self.ventana.bye()  # Cierra la ventana de turtle

# Crear una instancia de TortugaControl
mi_controlador = TortugaControl()

# Ejecutar el programa
mi_controlador.ejecutar()
