import turtle

class TortugaControl:
    def __init__(self):
        """Inicializa la pantalla, la tortuga y los comandos."""
        self.ventana = turtle.Screen()
        self.ventana.title("Controla la Tortuga con Comandos Binarios")  # Título de la ventana
        
        # Crear la tortuga
        self.mi_tortuga = turtle.Turtle()
        
        # Diccionario de comandos binarios
        self.comandos = {
            '00': self.mover_adelante,
            '01': self.mover_atras,
            '10': self.girar_izquierda,
            '11': self.girar_derecha
        }
        
        # Configurar los controles
        self.configurar_controles()
    
    def configurar_controles(self):
        """Configura las teclas para ingresar comandos binarios."""
        self.ventana.listen()  # La ventana está lista para "escuchar" las teclas
        # Asignar teclas a los comandos binarios
        self.ventana.onkey(lambda: self.recibir_comando('00'), "0")  # Tecla '0' para comando '00'
        self.ventana.onkey(lambda: self.recibir_comando('01'), "1")  # Tecla '1' para comando '01'
        self.ventana.onkey(lambda: self.recibir_comando('10'), "2")  # Tecla '2' para comando '10'
        self.ventana.onkey(lambda: self.recibir_comando('11'), "3")  # Tecla '3' para comando '11'
    
    def recibir_comando(self, comando_binario):
        """Recibe el comando binario y ejecuta la acción correspondiente."""
        if comando_binario in self.comandos:
            accion = self.comandos[comando_binario]
            accion()
        else:
            print(f"Comando '{comando_binario}' no reconocido. Use '00', '01', '10', o '11'.")
    
    def mover_adelante(self):
        """Mueve la tortuga hacia adelante."""
        self.mi_tortuga.forward(20)  # Mueve la tortuga 20 pasos hacia adelante
    
    def mover_atras(self):
        """Mueve la tortuga hacia atrás."""
        self.mi_tortuga.backward(20)  # Mueve la tortuga 20 pasos hacia atrás
    
    def girar_izquierda(self):
        """Gira la tortuga a la izquierda."""
        self.mi_tortuga.left(30)  # Gira la tortuga 30 grados a la izquierda
    
    def girar_derecha(self):
        """Gira la tortuga a la derecha."""
        self.mi_tortuga.right(30)  # Gira la tortuga 30 grados a la derecha
    
    def ejecutar(self):
        """Ejecuta el bucle principal del programa."""
        self.ventana.mainloop()

# Crear una instancia de TortugaControl
mi_controlador = TortugaControl()

# Ejecutar el programa
mi_controlador.ejecutar()
